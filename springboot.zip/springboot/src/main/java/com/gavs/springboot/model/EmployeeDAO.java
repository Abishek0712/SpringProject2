package com.gavs.springboot.model;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmployeeDAO {
	public static Connection getcon() {
        Connection con =null;
        String strUserName="root";
        String strPassword="admin";
        try
        {
            java.util.Properties p = new java.util.Properties();
            p.put("user",strUserName);
            p.put("password",strPassword);
            String driverName="com.mysql.cj.jdbc.Driver";
            Class.forName(driverName);
            String url=("jdbc:mysql://localhost:3306/jjj");
            con= DriverManager.getConnection(url,p);
            
         }catch (SQLException sqe)
         {
            System.out.println("SQLException:  " + sqe.getMessage());
         }catch (Exception e2)
         {
            System.out.println("Exception:  " + e2.getMessage());
         }
        return con;
    }
public int addEmployee(int id,String name) 
{
	Connection cn=getcon();
	try
	{
		
		PreparedStatement st=cn.prepareStatement("INSERT INTO Employee(id,name) values(?,?)");
		st.setInt(1, id);
		st.setString(2,name);
		st.executeUpdate();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	return 0;
}
public int removeEmployee(int id)
{
	Connection cn=getcon();
	try
	{
		PreparedStatement st=cn.prepareStatement("DELETE from Employee where id=?");
		st.setInt(1, id);
		st.executeUpdate();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	return 0;
}
public int modifyEmployee(String name,int id)
{
	Connection cn=getcon();
	try
	{
		PreparedStatement st=cn.prepareStatement("UPDATE Employee SET name=? WHERE id=?");
		st.setString(1, name);
		st.setInt(2, id);
		st.executeUpdate();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	return 0;
}
}
