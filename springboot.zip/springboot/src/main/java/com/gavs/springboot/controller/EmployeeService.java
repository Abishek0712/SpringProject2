package com.gavs.springboot.controller;
import java.sql.SQLException;

import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.gavs.springboot.model.Employee;
import com.gavs.springboot.model.EmployeeDAO;
@RestController
public class EmployeeService {
	EmployeeDAO e = new EmployeeDAO();
	@RequestMapping("/hello")
    public String welcomepage() {
        return "hello to Spring REST Controller";
    }
    @RequestMapping(value="/findEmployee",method= RequestMethod.GET)
    public Employee homepage() {
        Employee emp=new Employee();
        emp.setId(123);
        emp.setName("Jobs");
        return emp;
    }
    @RequestMapping(value="/addEmployee",method= RequestMethod.POST)
    public int addEmployee(@RequestBody Employee emp) throws SQLException {
     int id=emp.getId();
     String name=emp.getName();
     e.addEmployee(id, name);
     System.out.println("ID:"+emp.getId());
     System.out.println("NAME:"+emp.getName());
     return 0;
    }
    @RequestMapping(value="/updateEmployee",method= RequestMethod.PUT)
    public int modifyEmployee(@RequestBody Employee emp) {
    	int id=emp.getId();
    	String name=emp.getName();
    	e.modifyEmployee(name,id);
        return 0;
    }
    @RequestMapping(value="/removeEmployee",method= RequestMethod.DELETE)
    public int removeEmployee(@RequestBody Employee emp) {
    	int id=emp.getId();
    	e.removeEmployee(id);
    	return 0;
     }
}
